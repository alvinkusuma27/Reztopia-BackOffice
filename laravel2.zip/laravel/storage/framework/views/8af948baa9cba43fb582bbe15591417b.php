<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>&copy; Copyright 2023 TA. All Rights Reserved.</p>
        </div>
        <div class="float-end">
            <p>
                Hand Crafted & Made Withs
                <span class="text-danger"><i class="bi bi-heart"></i></span>
            </p>
        </div>
    </div>
</footer>
<?php /**PATH D:\belajar\project\Reztopia\resources\views/tenant/components/footer.blade.php ENDPATH**/ ?>