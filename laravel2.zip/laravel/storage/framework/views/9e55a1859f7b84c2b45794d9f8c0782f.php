<?php $__env->startSection('title', 'TENANT'); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        function myFunction() {
            // var y = document.getElementById("pass");
            // if (y.type === "password") {
            //     y.type = "text";
            //     document.getElementById('pass').type = 'password';
            //     console.log('password');
            // } else {
            //     document.getElementById('pass').type = "text";
            //     y.type = "password";
            //     console.log('text');
            // }
            const togglePasswordEdit = document.querySelector("#togglePasswordEdit");
            const passwordEdit = document.querySelector("#passwordEdit");
            // console.log(togglePassword)

            togglePasswordEdit.addEventListener("click", function() {
                // toggle the type attribute
                const type = passwordEdit.getAttribute("type") === "password" ? "text" : "password";
                passwordEdit.setAttribute("type", type);
                console.log(type)
                // toggle the icon
                // this.classList.toggle("bi-eye");
            });

            // prevent form submit
            const form = document.getElementById("formEdit");
            form.addEventListener('submit', function(e) {
                e.preventDefault();
            });
        }

        const togglePassword = document.querySelector("#togglePassword");
        const password = document.querySelector("#password");
        // console.log(togglePassword, password)

        togglePassword.addEventListener("click", function() {
            // toggle the type attribute
            const type = password.getAttribute("type") === "password" ? "text" : "password";
            password.setAttribute("type", type);
            // console.log(type)
            // toggle the icon
            this.classList.toggle("bi-eye");
        });

        // prevent form submit
        const form = document.querySelector("form");
        form.addEventListener('submit', function(e) {
            e.preventDefault();
        });


        // const functionEdit = () => {

        //     var temp = document.getElementById("password");
        //     if (temp.type === "password") {
        //         temp.type = "text";
        //     } else {
        //         temp.type = "password";
        //     }
        // }
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('head'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/extensions/simple-datatables/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/pages/simple-datatables.css')); ?>">
    <style>
        form i {
            margin-left: -30px;
            cursor: pointer;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('container'); ?>
    <div class="page-heading">
        <h3>Data Akun</h3>
        <p>Atur data akun dan bundle disini</p>
    </div>
    <div class="page-content">
        <section class="row">
            <div class="col-12 col-lg-12">
                
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-end">
                                <button class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#modalCreate">Tambah</button>
                            </div>
                            <div class="card-body">
                                <table class="table table-striped" id="table1">
                                    <thead>
                                        <tr>
                                            <th>Nomor</th>
                                            <th>Nama</th>
                                            <th>Tenant</th>
                                            <th>Pengaturan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $outlet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-bold-500"><?php echo e($item->user[0]->id); ?></td>
                                                <td><?php echo e($item->user[0]->name); ?></td>
                                                <td class="text-bold-500"><?php echo e($item->name); ?></td>
                                                <td>
                                                    <button class="btn btn-outline-primary rounded-pill"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#modalEdit<?php echo e($item->id); ?>">Edit</button>
                                                    
                                                    <a href="<?php echo e(route('tenant.destroy', $item->id)); ?>"
                                                        data-bs-toggle="modal" class="btn btn-outline-danger ml-1"
                                                        data-bs-target="#modalDelete<?php echo e($item->id); ?>">
                                                        <i class="bi bi-trash-fill"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </div>

    <?php $__currentLoopData = $outlet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="modalDelete<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable" role="document">
                <div class="modal-content">
                    <div class="modal-header bg-danger d-flex justify-content-center">
                        <h5 class="modal-title" id="exampleModalCenterTitle">Delete User <?php echo e($item->user[0]->name); ?>

                        </h5>
                    </div>
                    <div class="modal-body">
                        <center>
                            <a href="<?php echo e(route('tenant.destroy', $item->id)); ?>" class="btn btn-danger">
                                <i class="bx bx-check d-block d-sm-none"></i>
                                <span class="d-none d-sm-block">Ya</span>
                            </a>
                            <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">
                                <i class="bx bx-x d-block d-sm-none"></i>
                                <span class="d-none d-sm-block ">Batal</span>
                            </button>
                        </center>
                    </div>
                    <div class="modal-footer">
                        <p class="m-auto text-muted">Tindakan ini tidak dapat diurungkan</p>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    
    <div class="modal fade text-left" id="modalCreate" tabindex="-1" role="dialog" aria-labelledby="myModalLabel33"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel33">Tambah Tenant</h4>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <i data-feather="x"></i>
                    </button>
                </div>
                <form action="<?php echo e(route('tenant.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <label>Nama: </label>
                        <div class="form-group">
                            <input type="text" placeholder="nama" name="name" value="<?php echo e(old('name')); ?>"
                                class="form-control">
                        </div>
                        <label>Tenant: </label>
                        <div class="form-group">
                            <input type="text" placeholder="Tenant" name="tenant" value="<?php echo e(old('tenant')); ?>"
                                class="form-control">
                        </div>
                        <label>Email: </label>
                        <div class="form-group">
                            <input type="email" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>"
                                class="form-control">
                        </div>
                        <label>Phone: </label>
                        <div class="form-group">
                            <input type="number" placeholder="Phone Number" name="phone" value="<?php echo e(old('phone')); ?>"
                                class="form-control">
                        </div>
                        <label>Password: </label>
                        <div class="form-group">
                            
                            
                            <input type="password" placeholder="Password" name="password" id="password"
                                class="form-control">
                            <input type="checkbox" class="ml-3" id="togglePassword"> Show Password
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">
                            <i class="bx bx-x d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Close</span>
                        </button>
                        <button type="submit" class="btn btn-primary ml-1" data-bs-dismiss="modal">
                            <i class="bx bx-check d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Tambah</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <?php $__currentLoopData = $outlet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade text-left" id="modalEdit<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
            aria-labelledby="myModalLabel33" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myModalLabel33">Edit Tenant <?php echo e($item->name); ?></h4>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            <i data-feather="x"></i>
                        </button>
                    </div>
                    <form action="<?php echo e(route('tenant.update', $item->id)); ?>" method="post" id="formEdit">
                        
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <label>Nama: </label>
                            <div class="form-group">
                                <input type="text" placeholder="nama" name="name"
                                    value="<?php echo e($item->user[0]->name); ?>" class="form-control">
                            </div>
                            <label>Tenant: </label>
                            <div class="form-group">
                                <input type="text" placeholder="Tenant" name="tenant" value="<?php echo e($item->name); ?>"
                                    class="form-control">
                            </div>
                            <label>Email: </label>
                            <div class="form-group">
                                <input type="email" placeholder="Email" name="email"
                                    value="<?php echo e($item->user[0]->email); ?>" class="form-control">
                            </div>
                            <label>Phone: </label>
                            <div class="form-group">
                                <input type="number" placeholder="Phone Number" name="phone"
                                    value="<?php echo e($item->user[0]->phone); ?>" class="form-control">
                            </div>
                            <label>Password: </label>
                            <div class="form-group">
                                
                                
                                <input type="password" placeholder="Password" name="password" id="passwordEdit"
                                    class="form-control">
                                <input type="checkbox" class="ml-3" id="togglePasswordEdit" onclick="myFunction()">
                                Show Password
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-warning ml-1" data-bs-dismiss="modal">
                                <i class="bx bx-check d-block d-sm-none"></i>
                                <span class="d-none d-sm-block">Edit</span>
                            </button>
                            <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">
                                <i class="bx bx-x d-block d-sm-none"></i>
                                <span class="d-none d-sm-block">Close</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/extensions/choices.js/public/assets/scripts/choices.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#tableLaporan').DataTable();
        });
    </script>
    <script src="<?php echo e(asset('assets/extensions/simple-datatables/umd/simple-datatables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pages/simple-datatables.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('tenant.components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\belajar\project\Reztopia\backend\resources\views/tenant/page/tenant.blade.php ENDPATH**/ ?>