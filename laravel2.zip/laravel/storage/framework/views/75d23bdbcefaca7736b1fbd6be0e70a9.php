<?php $__env->startSection('title', 'DASHBOARD'); ?>

<?php $__env->startSection('container'); ?>
    <div class="page-heading">
        <h3>Welcome Tenant <?php echo e(empty($outlet[0]) ? '0' : $outlet[0]->tenant_name); ?></h3>
        <p>All System are running smothly! you have 3 unread <span style="color:aqua">alert!</span> </p>
    </div>
    <div class="page-content">
        <section class="row">
            <div class="col-12 col-lg-12">
                <div class="row">
                    
                    <div class="col-6 col-lg-3 col-md-6">
                        <a href="<?php echo e(route('laporan')); ?>">
                            <div class="card">
                                <div class="card-body px-4 py-4-5">
                                    <div class="row">
                                        <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start">
                                            <div class="stats-icon purple mb-2">
                                                <i class="iconly-boldShow"></i>
                                            </div>
                                        </div>
                                        <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                            <h6 class="text-muted font-semibold">
                                                Number of Omzet
                                            </h6>
                                            <h6 class="font-extrabold mb-0">
                                                <?php echo e(!empty($total_order) ? number_format($total_order, 2, ',', '.') : '0'); ?>

                                            </h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-6 col-lg-3 col-md-6">
                        <a href="<?php echo e(route('laporan')); ?>">
                            <div class="card">
                                <div class="card-body px-4 py-4-5">
                                    <div class="row">
                                        <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start">
                                            <div class="stats-icon blue mb-2">
                                                <i class="iconly-boldProfile"></i>
                                            </div>
                                        </div>
                                        <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                            <h6 class="text-muted font-semibold">Number of Orders</h6>
                                            <h6 class="font-extrabold mb-0"><?php echo e($today_order); ?></h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>

                    </div>
                    <div class="col-6 col-lg-3 col-md-6">
                        <a href="<?php echo e(auth()->user()->roles == 'admin' ? route('tenant-control') : route('menu')); ?>">
                            <div class="card">
                                <div class="card-body px-4 py-4-5">
                                    <div class="row">
                                        <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start">
                                            <div class="stats-icon purple mb-2">
                                                <i class="iconly-boldShow"></i>
                                            </div>
                                        </div>
                                        <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                            <h6 class="text-muted font-semibold">
                                                <?php echo e(auth()->user()->roles == 'kantin' ? 'Number of Category' : 'Number of active tenants'); ?>

                                            </h6>
                                            <h6 class="font-extrabold mb-0">
                                                <?php if(auth()->user()->roles == 'kantin'): ?>
                                                    <?php echo e(empty($total_category) ? '0' : $total_category); ?>

                                                <?php else: ?>
                                                    <?php echo e(empty($active_tenant) ? '0' : $active_tenant); ?>

                                                <?php endif; ?>
                                            </h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-6 col-lg-3 col-md-6">
                        <a href="<?php echo e(auth()->user()->roles == 'admin' ? route('tenant-control') : route('menu')); ?>">
                            <div class="card">
                                <div class="card-body px-4 py-4-5">
                                    <div class="row">
                                        <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start">
                                            <div class="stats-icon blue mb-2">
                                                <i class="iconly-boldProfile"></i>
                                            </div>
                                        </div>
                                        <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                            <h6 class="text-muted font-semibold">
                                                <?php echo e(auth()->user()->roles == 'kantin' ? 'Number of Menu' : 'Number of inactive tenants'); ?>

                                            </h6>
                                            <h6 class="font-extrabold mb-0">
                                                <?php if(auth()->user()->roles == 'kantin'): ?>
                                                    <?php echo e(empty($total_menu) ? '0' : $total_menu); ?>

                                                <?php else: ?>
                                                    <?php echo e(empty($active_tenant) ? '0' : $active_tenant); ?>

                                                <?php endif; ?>
                                            </h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    
                    
                </div>
                
                <div class="row">
                    <div class="col-12 col-xl-6">
                        <div class="card">
                            <div class="card-header">
                                <h4>Order Details</h4>
                                <p>The total number of sessions within the date range. It is the period time a user is
                                    actively engaged with your website, page or app, etc</p>
                            </div>
                            <div class="card-body">
                                
                                <div class="row">
                                    
                                    <div class="col-12">
                                        <div id="chart-order"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-xl-6">
                        <div class="card">

                            <div class="card-header">
                                <h4><?php echo e(auth()->user()->roles == 'kantin' ? 'Top Product' : 'Top Tenant'); ?></h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover table-lg">
                                        <?php if(auth()->user()->roles == 'kantin'): ?>
                                            <thead>
                                                <tr>
                                                    <th>Product</th>
                                                    <th>Price</th>
                                                    <th>Order</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                
                                                <?php $__currentLoopData = $top_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td class="col-3">
                                                            <div class="d-flex align-items-center">
                                                                <p class="font-bold ms-3 mb-0"><?php echo e($item->name); ?></p>
                                                            </div>
                                                        </td>
                                                        <td class="col-auto">
                                                            <p class="mb-0">
                                                                Rp.<?php echo e(number_format($item->original_price)); ?>

                                                            </p>
                                                        </td>
                                                        <td>
                                                            <div class="col-auto">
                                                                <p class="mb-0"><?php echo e($item->total); ?></p>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        <?php else: ?>
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Total Order</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                
                                                <?php $__currentLoopData = $top_tenant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td class="col-3">
                                                            <div class="col-auto">
                                                                <p class="font-bold mb-0"><?php echo e($item->name); ?></p>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="col-auto">
                                                                <p class="mb-0"><?php echo e($item->total_order); ?></p>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        <?php endif; ?>
                                    </table>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
                // dd(json_encode($order_grafik), json_encode($bulan_grafik));
            ?>
            <?php $__env->startPush('scripts'); ?>
                <script src="<?php echo e(asset('assets/extensions/apexcharts/apexcharts.min.js')); ?>"></script>
                
                <?php if(auth()->user()->roles == 'kantin'): ?>
                    <script>
                        // console.log(json_encode($order_grafik), json_encode($bulan_grafik))
                        var areaOptions = {
                            series: [{
                                    name: "Order",
                                    // data: <?php echo json_encode($bulan_grafik); ?>,
                                    data: <?php echo json_encode($order_grafik); ?>,
                                },
                                // {
                                //     name: "series2",
                                //     data: [11, 32, 45, 32, 34, 52, 41],
                                // },
                            ],
                            chart: {
                                height: 350,
                                type: "area",
                            },
                            dataLabels: {
                                enabled: false,
                            },
                            stroke: {
                                curve: "smooth",
                            },
                            xaxis: {
                                type: "datetime",
                                categories: <?php echo json_encode($bulan_grafik); ?>,
                            },
                            tooltip: {
                                x: {
                                    format: "dd/MM/yy HH:mm",
                                },
                            },
                        };

                        var area = new ApexCharts(document.querySelector("#chart-order"), areaOptions);

                        area.render();
                    </script>
                <?php endif; ?>
            <?php $__env->stopPush(); ?>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tenant.components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\belajar\project\Reztopia\laravel\resources\views/tenant/page/dashboard.blade.php ENDPATH**/ ?>