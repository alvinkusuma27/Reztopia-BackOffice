<?php $__env->startSection('title', 'MENU'); ?>
<?php $__env->startPush('head'); ?>
    <style>
        .color-card {
            background-color: rgb(14, 12, 27);
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('container'); ?>
    <div class="page-heading">
        <div class="d-flex justify-content-lg-between">
            <div class="col-lg-12 col-md-6">
                <div class="flex-start">
                    
                    <h3>Produk Kantin <?php echo e($outlet_name[0]->name != null ? $outlet_name[0]->name : 'nan'); ?></h3>
                    <p>Pantau produk kantin dari sini</p>
                </div>
                <div class="flex-end">
                    <div class="btn-group mb-1 mr-3">
                        <div class="dropdown">
                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <i class="bi bi-pencil"></i>
                                Atur Category
                            </button>
                            <div class="dropdown-menu">
                                <button class="dropdown-item" data-bs-toggle="modal"
                                    data-bs-target="#modalTambahCategory"><i class="bi bi-plus"></i>
                                    <span>Tambah Category</span></button>
                                <button class="dropdown-item" data-bs-toggle="modal" data-bs-target="#modalEditCategory"><i
                                        class="bi bi-pencil"></i>
                                    <span>Edit Category</span></button>
                                <button class="dropdown-item" data-bs-toggle="modal"
                                    data-bs-target="#modalDeleteCategory"><i class="bi bi-trash"></i>
                                    <span>Hapus Category</span></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="page-content">
        <section class="row">
            <div class="col-12 col-lg-12">
                <div class="row">
                    <?php $__currentLoopData = $for_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class="col-6 col-lg-4 col-md-6">
                            <div class="card">
                                <div class="card-body px-4 py-4-5">
                                    <div class="row">
                                        <h6 class="text-muted font-semibold">
                                            <?php echo e($item->name); ?>

                                        </h6>
                                        <h6 class="font-extrabold mb-0"><?php echo e($item->jumlah_produk); ?></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row">
                    <div class="col-12 col-xl-12">
                        <div class="card">
                            <div class="card-header">
                                <h4>Produk</h4>
                                <div class="d-flex justify-content-lg-between">
                                    <p>Produk yang dijual baik ready stok maupun out of stok</p>
                                    <div class="btn-group mb-1">
                                        <div class="dropdown">
                                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="dropdown"
                                                aria-haspopup="true" aria-expanded="false">
                                                Atur Produk
                                            </button>
                                            <div class="dropdown-menu">
                                                <button class="dropdown-item" href="#" data-bs-toggle="modal"
                                                    data-bs-target="#modalTambahProduk"><i class="bi bi-plus"></i>
                                                    <span>Tambah Produk</span></button>
                                                
                                                <button class="dropdown-item" href="#" data-bs-toggle="modal"
                                                    data-bs-target="#modalDeleteProduct"><i class="bi bi-trash"></i>
                                                    <span>Hapus Produk</span></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-3 col-md-6 col-sm-12">
                                            <div class="card">
                                                <div class="card-content">
                                                    <button class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#modalEditProduk<?php echo e($item->id_product); ?>">
                                                        <img src="<?php echo e($item->image_product != null ? asset('storage/uploads/products/' . $item->image_product) : asset('assets/no-image.png')); ?>"
                                                            class="card-img-top img-fluid" alt="<?php echo e($item->image_product); ?>">
                                                        <div class="card-body color-card">
                                                            <h5 class="card-title"><?php echo e($item->nama_makanan); ?></h5>
                                                            <p class="card-text">
                                                                <?php echo e($item->description); ?>

                                                            </p>
                                                            <p class="card-text">
                                                                Rp.<?php echo e(number_format($item->price_final)); ?>

                                                            </p>
                                                        </div>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    
    <div class="modal fade" id="modalTambahCategory" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-center">
                    <h5 class="modal-title" id="exampleModalScrollableTitle">Tambah Category</h5>
                </div>
                <form action="<?php echo e(route('menu.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <input type="text" hidden name="id_outlet" value="<?php echo e($id_outlet); ?>">
                            <label for="basicInput">Nama Category</label>
                            <input type="text" class="form-control mt-3" id="basicInput"
                                name="name"value="<?php echo e(old('name')); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label for="basicInput">Deskripsi</label>
                            <input type="text" class="form-control mt-3" id="basicInput" name="description"
                                value="<?php echo e(old('description')); ?>">
                        </div>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">
                            <i class="bx bx-x d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Close</span>
                        </button>
                        <button type="submit" class="btn btn-primary ml-1" data-bs-dismiss="modal">
                            <i class="bx bx-check d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Accept</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="modalEditCategory" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-center">
                    <h5 class="modal-title" id="exampleModalScrollableTitle">Edit Kategori</h5>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-4">
                                <div class="card">
                                    <div class="card-content">
                                        <button class="dropdown-item" href="#" data-bs-toggle="modal"
                                            data-bs-target="#modalEditDetailCategory<?php echo e($item->id); ?>">
                                            <div class="card-body color-card">
                                                
                                                <h5 class="card-title text-center mt-2"><?php echo e($item->name); ?></h5>
                                                
                                            </div>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">
                        <i class="bx bx-x d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Close</span>
                    </button>
                    <button type="submit" class="btn btn-primary ml-1" data-bs-dismiss="modal">
                        <i class="bx bx-check d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Accept</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="modalEditDetailCategory<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable" role="document">
                <div class="modal-content">
                    <div class="modal-header d-flex justify-content-center">
                        <h5 class="modal-title" id="exampleModalScrollableTitle">Edit Category</h5>
                    </div>
                    <form action="<?php echo e(route('menu.update', $item->id)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <div class="form-group mb-3">
                                <input type="text" hidden name="id_outlet" value="<?php echo e($id_outlet); ?>">
                                <input type="text" hidden name="id_category" value="<?php echo e($item->id); ?>">
                                <label for="basicInput">Nama Category</label>
                                <input type="text" class="form-control mt-3" id="basicInput"
                                    name="name"value="<?php echo e($item->name); ?>">
                            </div>
                            <p>Pilih Makanan dan Minuman</p>
                            <div class="row">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-4">
                                        <div class="card">
                                            <div class="card-content">
                                                <div class="card-body color-card">
                                                    <div class="custom-control custom-checkbox image-checkbox">
                                                        <input type="checkbox" class="custom-control-input"
                                                            name="id_product[]" id="ck<?php echo e($item->id_product); ?>"
                                                            value="<?php echo e($item->id_product); ?>">
                                                        <label class="custom-control-label"
                                                            for="ck<?php echo e($item->id_product); ?>">
                                                            <img src="<?php echo e($item->image_product != null ? asset('storage/uploads/products/' . $item->image_product) : asset('assets/no-image.png')); ?>"
                                                                alt="#" class="img-fluid">
                                                            <h5 class="mt-2"><?php echo e($item->nama_makanan); ?></h5>
                                                            <p><?php echo e($item->description); ?></p>
                                                            <p>Rp.<?php echo e(number_format($item->original_price)); ?></p>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">
                                <i class="bx bx-x d-block d-sm-none"></i>
                                <span class="d-none d-sm-block">Close</span>
                            </button>
                            <button type="submit" class="btn btn-primary ml-1" data-bs-dismiss="modal">
                                <i class="bx bx-check d-block d-sm-none"></i>
                                <span class="d-none d-sm-block">Accept</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <div class="modal fade" id="modalDeleteCategory" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-center">
                    <h5 class="modal-title" id="exampleModalScrollableTitle">HAPUS Category</h5>
                </div>
                <form action="<?php echo e(route('menu.destroy')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="row">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-4">
                                    <div class="card">
                                        <div class="card-content">
                                            <div class="card-body color-card">
                                                <div class="custom-control custom-checkbox image-checkbox">
                                                    <input type="checkbox" class="custom-control-input"
                                                        name="id_product_<?php echo e($item->id); ?>" id="ck<?php echo e($item->id); ?>"
                                                        value="<?php echo e($item->id); ?>">
                                                    <label class="custom-control-label" for="ck<?php echo e($item->id); ?>">
                                                        <h5 class="mt-2"><?php echo e($item->name); ?></h5>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">
                            <i class="bx bx-x d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Close</span>
                        </button>
                        <button type="submit" class="btn btn-primary ml-1" data-bs-dismiss="modal">
                            <i class="bx bx-check d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Accept</span>
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    
    


    
    <div class="modal fade" id="modalTambahProduk" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-center">
                    <h5 class="modal-title" id="exampleModalScrollableTitle">Tambah Produk</h5>
                </div>
                <form action="<?php echo e(route('menu.store.product')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label for="basicInput">Nama Produk</label>
                            <input type="text" class="form-control mt-3" id="basicInput" name="name"
                                value="<?php echo e(old('name')); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label for="basicInput">Deskripsi</label>
                            <textarea type="text" class="form-control mt-3" id="basicInput" name="description"><?php echo e(old('description')); ?></textarea>
                        </div>
                        <div class="form-group mb-3">
                            <label for="basicInput">Harga Jual</label>
                            <input type="number" class="form-control mt-3" id="basicInput" name="original_price"
                                value="<?php echo e(old('original_price')); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label for="basicInput">Harga Modal</label>
                            <input type="number" class="form-control mt-3" id="basicInput" name="cost_price"
                                value="<?php echo e(old('cost_price')); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label for="basicInput">Diskon</label>
                            <input type="number" class="form-control mt-3" id="basicInput" name="discount"
                                value="<?php echo e(old('discount')); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label for="basicInput">Kategori</label>
                            <select class="form-select" name="id_category">
                                <option <?php echo e(old('id_category') == null ? 'selected' : ''); ?> hidden>Pilih Salah satu kategori
                                </option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e(old('id_category') != null ? old('id_category') : $item->id); ?>"
                                        <?php echo e(old('id_category') != null ? 'selected' : ''); ?>>
                                        <?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group mb-3">
                            <label for="basicInput">Upload Foto Produk</label>
                            <input class="form-control mt-2" type="file" name="image" id="formFile">
                            <p class="text-muted mt-1">ukuran foto maksimal 2mb</p>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">
                            <i class="bx bx-x d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Close</span>
                        </button>
                        <button type="submit" class="btn btn-primary ml-1" data-bs-dismiss="modal">
                            <i class="bx bx-check d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Accept</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="modalEditProduk<?php echo e($item->id_product); ?>" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable" role="document">
                <div class="modal-content">
                    <div class="modal-header d-flex justify-content-center">
                        <h5 class="modal-title" id="exampleModalScrollableTitle">Edit Produk</h5>
                    </div>
                    <form action="<?php echo e(route('menu.update.product', $item->id_product)); ?>" method="post"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <div class="form-group mb-3">
                                <input type="hidden" name="id_product" value="<?php echo e($item->id_product); ?>">
                                <label for="basicInput">Nama Produk</label>
                                <input type="text" class="form-control mt-3" id="basicInput" name="name"
                                    value="<?php echo e(old('name') != null ? old('name') : $item->nama_makanan); ?>">
                            </div>
                            <div class="form-group mb-3">
                                <label for="basicInput">Deskripsi</label>
                                <textarea type="text" class="form-control mt-3" id="basicInput" name="description"><?php echo e(old('description') != null ? old('description') : $item->description); ?></textarea>
                            </div>
                            <div class="form-group mb-3">
                                <label for="basicInput">Harga Jual</label>
                                <input type="number" class="form-control mt-3" id="basicInput" name="original_price"
                                    value="<?php echo e(old('original_price') != null ? old('original_price') : $item->original_price); ?>">
                            </div>
                            <div class="form-group mb-3">
                                <label for="basicInput">Harga Modal</label>
                                <input type="number" class="form-control mt-3" id="basicInput" name="cost_price"
                                    value="<?php echo e(old('cost_price') != null ? old('cost_price') : $item->cost_price); ?>">
                            </div>
                            <div class="form-group mb-3">
                                <label for="basicInput">Diskon</label>
                                <input type="number" class="form-control mt-3" id="basicInput" name="discount"
                                    value="<?php echo e(old('discount') != null ? old('discount') : $item->discount); ?>">
                            </div>
                            <div class="form-group mb-3">
                                <label for="basicInput">Kategori</label>
                                <select class="form-select" name="id_category">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(old('id_category')): ?>
                                            <option value="<?php echo e(old('id_category')); ?>"
                                                <?php echo e(old('id_category') == $row->id ? 'selected' : ''); ?>>
                                                <?php echo e($row->name); ?>

                                            </option>
                                        <?php else: ?>
                                            <option value="<?php echo e($row->id); ?>"
                                                <?php echo e($item->id_category == $row->id ? 'selected' : ''); ?>>
                                                <?php echo e($row->name); ?>

                                            </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group mb-3">
                                <label for="basicInput">Upload Foto Produk</label>
                                <input class="form-control mt-2" type="file" name="image" id="formFile">
                                <p class="text-muted mt-1">ukuran foto maksimal 2mb</p>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">
                                <i class="bx bx-x d-block d-sm-none"></i>
                                <span class="d-none d-sm-block">Close</span>
                            </button>
                            <button type="submit" class="btn btn-primary ml-1" data-bs-dismiss="modal">
                                <i class="bx bx-check d-block d-sm-none"></i>
                                <span class="d-none d-sm-block">Accept</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <div class="modal fade" id="modalDeleteProduct" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-center">
                    <h5 class="modal-title" id="exampleModalScrollableTitle">HAPUS PRODUCT</h5>
                </div>
                <form action="<?php echo e(route('menu.destroy.product')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body mx-3">
                        <div class="row">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-4">
                                    <div class="card">
                                        <div class="card-content">
                                            <div class="card-body color-card">
                                                <div class="custom-control custom-checkbox image-checkbox">
                                                    <input type="checkbox" class="custom-control-input"
                                                        name="id_product_<?php echo e($item->id_product); ?>"
                                                        id="ck<?php echo e($item->id_product); ?>" value="<?php echo e($item->id_product); ?>">
                                                    <label class="custom-control-label" for="ck<?php echo e($item->id_product); ?>">
                                                        <img src="<?php echo e($item->image_product != null ? asset('storage/uploads/products/' . $item->image_product) : asset('assets/no-image.png')); ?>"
                                                            alt="#" class="img-fluid">
                                                        <h5 class="mt-2"><?php echo e($item->nama_makanan); ?></h5>
                                                        <p><?php echo e($item->description); ?></p>
                                                        <p>Rp.<?php echo e(number_format($item->original_price)); ?></p>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">
                            <i class="bx bx-x d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Close</span>
                        </button>
                        <button type="submit" class="btn btn-danger ml-1" data-bs-dismiss="modal">
                            <i class="bx bx-check d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Delete</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/extensions/choices.js/public/assets/scripts/choices.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('tenant.components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\belajar\project\Reztopia\backend\resources\views/tenant/page/menu.blade.php ENDPATH**/ ?>